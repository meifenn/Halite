#!/usr/bin/env python3
import math
import random
import logging
import hlt
from hlt import constants
from hlt.positionals import Direction, Position

""" <<<Game Begin>>> """
game = hlt.Game()
game.ready("CaitVi")

logging.info(f"Successfully created bot! My Player ID is {game.my_id}.")

ship_stage = {}  # Track each ship's current task

# Utility Functions
def get_neighbors(position):
    """Returns valid neighboring positions."""
    directions = [Direction.North, Direction.South, Direction.East, Direction.West]
    neighbors = []
    for direction in directions:
        neighbors.append(position.directional_offset(direction))
    return neighbors

def heuristic(pos1, pos2):
    """Manhattan distance heuristic."""
    return abs(pos1.x - pos1.x) + abs(pos1.y - pos2.y)

def a_star(game_map, source, target):
    """A* pathfinding to navigate from source to target."""
    open_set = [source]
    closed_set = set()
    came_from = {}

    gScore = {source: 0}
    fScore = {source: heuristic(source, target)}

    while open_set:
        current = min(open_set, key=lambda pos: fScore.get(pos, float('inf')))

        if current == target:
            path = []
            while current in came_from:
                path.insert(0, current)
                current = came_from[current]
            return path

        open_set.remove(current)
        closed_set.add(current)

        for neighbor in get_neighbors(current):
            if neighbor in closed_set or game_map[neighbor].is_occupied:
                continue

            tentative_gScore = gScore[current] + game_map[neighbor].halite_amount / 10
            if neighbor not in open_set:
                open_set.append(neighbor)

            if tentative_gScore >= gScore.get(neighbor, float('inf')):
                continue

            came_from[neighbor] = current
            gScore[neighbor] = tentative_gScore
            fScore[neighbor] = gScore[neighbor] + heuristic(neighbor, target)

    return []

def calculate_halite_density(game_map, center, radius):
    """Calculates the average halite density within a radius."""
    total_halite = 0
    cells_counted = 0

    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            pos = Position(center.x + dx, center.y + dy)
            pos = game_map.normalize(pos)  # Ensure position is valid on the toroidal map
            total_halite += game_map[pos].halite_amount
            cells_counted += 1

    return total_halite / cells_counted if cells_counted > 0 else 0

def find_best_halite_zone(game_map, radius):
    """Finds the best position with the highest halite density."""
    best_position = None
    max_halite = 0

    for x in range(game_map.width):
        for y in range(game_map.height):
            position = Position(x, y)
            density = calculate_halite_density(game_map, position, radius)
            if density > max_halite:
                max_halite = density
                best_position = position

    return best_position

""" <<<Game Loop>>> """
while True:
    game.update_frame()
    me = game.me
    game_map = game.game_map

    command_queue = []
    shipyard_density = calculate_halite_density(game_map, me.shipyard.position, 5)

    if shipyard_density < 100:  # Threshold for sparse halite
        best_halite_zone = find_best_halite_zone(game_map, 5)

        if best_halite_zone and me.halite_amount >= constants.DROPOFF_COST:
            for ship in me.get_ships():
                if ship.halite_amount >= constants.DROPOFF_COST:
                    path = a_star(game_map, ship.position, best_halite_zone)
                    if path:
                        next_position = path[0]
                        direction = game_map.get_unsafe_moves(ship.position, next_position)[0]
                        game_map[ship.position.directional_offset(direction)].mark_unsafe(ship)
                        command_queue.append(ship.move(direction))
                    else:
                        command_queue.append(ship.stay_still())

                    if ship.position == best_halite_zone:
                        command_queue.append(ship.make_dropoff())
                    break

    for ship in me.get_ships():
        if ship.id not in ship_stage:
            ship_stage[ship.id] = 'go_to_collect'

        if ship_stage[ship.id] == 'go_to_collect':
            halite_values = {}
            direction_values = {}
            for direction in [Direction.North, Direction.South, Direction.East, Direction.West]:
                pos = ship.position.directional_offset(direction)
                if not game_map[pos].is_occupied:
                    halite_values[pos] = game_map[pos].halite_amount
                    direction_values[pos] = direction

            if halite_values:
                highest_halite_pos = max(halite_values, key=halite_values.get)
                direction = direction_values[highest_halite_pos]
                game_map[ship.position.directional_offset(direction)].mark_unsafe(ship)
                command_queue.append(ship.move(direction))
            else:
                command_queue.append(ship.stay_still())

            ship_stage[ship.id] = 'collecting'

        elif ship_stage[ship.id] == 'collecting':
            command_queue.append(ship.stay_still())
            if ship.halite_amount >= constants.MAX_HALITE or game_map[ship.position].halite_amount < 20:
                ship_stage[ship.id] = 'back_home' if ship.halite_amount >= constants.MAX_HALITE else 'go_to_collect'

        elif ship_stage[ship.id] == 'back_home':
            path = a_star(game_map, ship.position, me.shipyard.position)
            if path:
                next_position = path[0]
                direction = game_map.get_unsafe_moves(ship.position, next_position)[0]
                game_map[ship.position.directional_offset(direction)].mark_unsafe(ship)
                command_queue.append(ship.move(direction))
            else:
                command_queue.append(ship.stay_still())

            if ship.position == me.shipyard.position:
                ship_stage[ship.id] = 'go_to_collect'

    if game.turn_number <= constants.MAX_TURNS - 50 and me.halite_amount >= constants.SHIP_COST and not game_map[me.shipyard].is_occupied:
        command_queue.append(me.shipyard.spawn())

    game.end_turn(command_queue)
